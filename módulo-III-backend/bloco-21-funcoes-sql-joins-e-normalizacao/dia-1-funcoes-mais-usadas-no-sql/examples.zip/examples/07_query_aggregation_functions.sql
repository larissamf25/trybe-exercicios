-- média
SELECT AVG(rental_duration) FROM sakila.film;

-- mínimo
SELECT MIN(rental_duration) FROM sakila.film;
-- máximo
SELECT MAX(rental_duration) FROM sakila.film;
-- soma
SELECT SUM(rental_duration) FROM sakila.film;
-- contagem
SELECT COUNT(rental_duration) FROM sakila.film;

-- ⚠️ Cuidado com valores nulos no uso do avg e do count
SELECT count(address2) FROM address;
SELECT count(coalesce(address2, "")) FROM address;
